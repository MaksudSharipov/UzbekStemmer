name = UzbekStemmer

version = 0.2.0

author = Maksud Sharipov, Ulugbek Salaev, Allabergan Yuldashev, Jasur Sobirov

ulugbek0302@gmail.com

Uzbek Stemmer for Python

The Uzbek stemming algorithm was created by [Maksud Sharipov, Ulugbek Salaev, Allabergan Yuldashev, Jasur Sobirov]. It stems all Uzbek words and it is not included any lexicon.

github url: https://github.com/UlugbekSalaev/UzbekStemmer
